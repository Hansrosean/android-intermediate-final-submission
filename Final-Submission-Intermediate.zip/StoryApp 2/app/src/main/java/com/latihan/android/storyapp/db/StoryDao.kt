package com.latihan.android.storyapp.db

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.latihan.android.storyapp.api.ListStoryItem

@Dao
interface StoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(quote: List<ListStoryItem>)

    @Query("SELECT * FROM liststoryitem")
    fun getAllStory(): PagingSource<Int, ListStoryItem>

    @Query("DELETE FROM liststoryitem")
    suspend fun deleteAll()
}